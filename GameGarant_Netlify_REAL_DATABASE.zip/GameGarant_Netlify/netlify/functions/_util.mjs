import { getDatabase } from '@netlify/database';
import crypto from 'node:crypto';

export const db = getDatabase();
export const json = (data, status=200) => Response.json(data,{status,headers:{'cache-control':'no-store'}});
export function body(req){ return req.json().catch(()=>({})); }
export function id(){ return crypto.randomBytes(10).toString('hex'); }
export function hashPassword(password){
  const salt=crypto.randomBytes(16).toString('hex');
  const hash=crypto.scryptSync(String(password),salt,64).toString('hex');
  return `${salt}:${hash}`;
}
export function verifyPassword(password,stored){
  try{ const [salt,hex]=String(stored).split(':'); const got=crypto.scryptSync(String(password),salt,64); const expected=Buffer.from(hex,'hex'); return got.length===expected.length && crypto.timingSafeEqual(got,expected); }catch{return false;}
}
export function adminSecret(req){ return req.headers.get('x-admin-secret') || ''; }
export function requireAdmin(req){
  const secret=adminSecret(req);
  return !!secret && !!process.env.ADMIN_SECRET && secret===process.env.ADMIN_SECRET;
}
export function publicUser(r){ return {id:r.id,name:r.name,username:r.username,phone:r.phone||'',role:r.role,balance:Number(r.balance||0),blocked:!!r.blocked,createdAt:r.created_at,updatedAt:r.updated_at}; }
export function publicTrade(r){
  const p=r.payload||{};
  return {...p,id:r.id,sellerId:r.seller_id,sellerUsername:r.seller_username,buyerId:r.buyer_id,buyerUsername:r.buyer_username,title:r.title,category:r.category,subcategory:r.subcategory,gameName:r.game_name,price:Number(r.price||0),status:r.status,createdAt:r.created_at,updatedAt:r.updated_at};
}
