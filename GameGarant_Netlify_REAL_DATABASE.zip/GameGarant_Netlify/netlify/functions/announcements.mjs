import { db, json, body, id, requireAdmin } from './_util.mjs';
export default async (req)=>{
  if(req.method==='GET'){
    const rows=await db.sql`SELECT id,title,body,author,created_at FROM announcements ORDER BY created_at DESC`;
    return json({ok:true,announcements:rows.map(x=>({...x,createdAt:x.created_at}))});
  }
  if(!requireAdmin(req)) return json({ok:false,error:'Admin ruxsati kerak'},403);
  if(req.method==='POST'){
    const d=await body(req); if(!d.title||!d.body) return json({ok:false,error:'Sarlavha va matn kerak'},400);
    await db.sql`INSERT INTO announcements(id,title,body,author) VALUES(${id()},${d.title},${d.body},${d.author||'FenixVertex'})`;
    return json({ok:true});
  }
  if(req.method==='DELETE'){
    const aid=new URL(req.url).searchParams.get('id'); if(!aid) return json({ok:false,error:'ID kerak'},400);
    await db.sql`DELETE FROM announcements WHERE id=${aid}`; return json({ok:true});
  }
  return json({ok:false,error:'Method noto‘g‘ri'},405);
};
export const config={path:'/api/announcements'};
