import { db, json, body, id, hashPassword, verifyPassword, publicUser } from './_util.mjs';

export default async (req)=>{
  const data=await body(req);
  if(req.method==='POST' && data.action==='register'){
    const name=String(data.name||'').trim(), username=String(data.username||'').trim(), password=String(data.password||'');
    if(!name||!username||password.length<6) return json({ok:false,error:'Ma’lumotlar noto‘g‘ri'},400);
    if(!/^[a-zA-Z0-9_]{3,20}$/.test(username)) return json({ok:false,error:'Username noto‘g‘ri'},400);
    const exists=await db.sql`SELECT id FROM users WHERE lower(username)=lower(${username}) LIMIT 1`;
    if(exists.length) return json({ok:false,error:'Bu username band'},409);
    const u={id:id(),name,username,phone:'',password_hash:hashPassword(password),role:'buyer',balance:0,blocked:false};
    await db.sql`INSERT INTO users(id,name,username,phone,password_hash,role,balance,blocked) VALUES(${u.id},${u.name},${u.username},${u.phone},${u.password_hash},${u.role},${u.balance},${u.blocked})`;
    return json({ok:true,user:{...u,createdAt:new Date().toISOString()},token:u.id});
  }
  if(req.method==='POST' && data.action==='login'){
    const username=String(data.username||'').trim(); const password=String(data.password||'');
    let rows=await db.sql`SELECT * FROM users WHERE lower(username)=lower(${username}) LIMIT 1`;
    if(!rows.length && process.env.ADMIN_USERNAME && username.toLowerCase()===String(process.env.ADMIN_USERNAME).toLowerCase() && process.env.ADMIN_PASSWORD && password===process.env.ADMIN_PASSWORD){
      const adminId='8449313911';
      const hp=hashPassword(password);
      await db.sql`INSERT INTO users(id,name,username,phone,password_hash,role,balance,blocked) VALUES(${adminId},${process.env.ADMIN_NAME||'Fenix Vertex'},${process.env.ADMIN_USERNAME},'',${hp},'admin',0,false) ON CONFLICT(id) DO UPDATE SET password_hash=EXCLUDED.password_hash,role='admin',blocked=false`;
      rows=await db.sql`SELECT * FROM users WHERE id=${adminId}`;
    }
    if(!rows.length || !verifyPassword(password,rows[0].password_hash)) return json({ok:false,error:'Login yoki parol noto‘g‘ri'},401);
    const u=rows[0]; if(u.blocked) return json({ok:false,error:'Hisobingiz bloklangan'},403);
    return json({ok:true,user:publicUser(u),token:u.id});
  }
  return json({ok:false,error:'Method noto‘g‘ri'},405);
};
export const config={path:'/api/auth'};
