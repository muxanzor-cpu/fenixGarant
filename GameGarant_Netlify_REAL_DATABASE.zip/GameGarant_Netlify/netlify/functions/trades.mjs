import { db, json, body, publicTrade } from './_util.mjs';
export default async (req)=>{
  if(req.method==='GET'){
    const rows=await db.sql`SELECT * FROM trades ORDER BY updated_at DESC, created_at DESC`;
    return json({ok:true,trades:rows.map(publicTrade)});
  }
  if(req.method==='POST'){
    const t=await body(req); if(!t.id||!t.sellerId||!t.title) return json({ok:false,error:'E’lon ma’lumotlari to‘liq emas'},400);
    const payload={...t};
    delete payload.id; delete payload.sellerId; delete payload.sellerUsername; delete payload.buyerId; delete payload.buyerUsername; delete payload.title; delete payload.category; delete payload.subcategory; delete payload.gameName; delete payload.price; delete payload.status; delete payload.createdAt; delete payload.updatedAt;
    await db.sql`INSERT INTO trades(id,seller_id,seller_username,buyer_id,buyer_username,title,category,subcategory,game_name,price,status,payload,created_at,updated_at)
      VALUES(${t.id},${t.sellerId},${t.sellerUsername||''},${t.buyerId||null},${t.buyerUsername||null},${t.title},${t.category||null},${t.subcategory||null},${t.gameName||null},${Number(t.price)||0},${t.status||'created'},${JSON.stringify(payload)}::jsonb,${t.createdAt||new Date().toISOString()},NOW())
      ON CONFLICT(id) DO UPDATE SET seller_id=EXCLUDED.seller_id,seller_username=EXCLUDED.seller_username,buyer_id=EXCLUDED.buyer_id,buyer_username=EXCLUDED.buyer_username,title=EXCLUDED.title,category=EXCLUDED.category,subcategory=EXCLUDED.subcategory,game_name=EXCLUDED.game_name,price=EXCLUDED.price,status=EXCLUDED.status,payload=EXCLUDED.payload,updated_at=NOW()`;
    return json({ok:true});
  }
  if(req.method==='DELETE'){
    const id=new URL(req.url).searchParams.get('id'); if(!id) return json({ok:false,error:'ID kerak'},400);
    await db.sql`DELETE FROM trades WHERE id=${id}`; return json({ok:true});
  }
  return json({ok:false,error:'Method noto‘g‘ri'},405);
};
export const config={path:'/api/trades'};
