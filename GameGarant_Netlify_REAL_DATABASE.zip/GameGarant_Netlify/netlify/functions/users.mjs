import { db, json, body, publicUser, requireAdmin } from './_util.mjs';
export default async (req)=>{
  if(req.method==='GET'){
    const rows=await db.sql`SELECT * FROM users ORDER BY created_at DESC`;
    return json({ok:true,users:rows.map(publicUser)});
  }
  if(req.method==='PATCH'){
    if(!requireAdmin(req)) return json({ok:false,error:'Admin ruxsati kerak'},403);
    const d=await body(req); if(!d.id) return json({ok:false,error:'ID kerak'},400);
    if(d.action==='block') await db.sql`UPDATE users SET blocked=${!!d.blocked},updated_at=NOW() WHERE id=${d.id}`;
    if(d.action==='balance') await db.sql`UPDATE users SET balance=${Number(d.balance)||0},updated_at=NOW() WHERE id=${d.id}`;
    const rows=await db.sql`SELECT * FROM users WHERE id=${d.id}`;
    return json({ok:true,user:rows[0]?publicUser(rows[0]):null});
  }
  return json({ok:false,error:'Method noto‘g‘ri'},405);
};
export const config={path:'/api/users'};
